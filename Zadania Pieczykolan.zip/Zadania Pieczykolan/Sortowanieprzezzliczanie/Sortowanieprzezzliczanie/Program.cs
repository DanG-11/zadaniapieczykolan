﻿using System;

class Program
{
    static void Main()
    {
        Random rand = new Random();
        int n = 10;
        int[] tab = new int[n];

        for (int i = 0; i < n; i++)
        {
            tab[i] = rand.Next(-50, 51);
        }

        Console.WriteLine("Tablica przed sortowaniem:");
                Wypisz(tab);

        for (int i = 0; i < n - 1; i++)
        {
            for (int j = 0; j < n - 1 - i; j++)
            {
                if (tab[j] > tab[j + 1])
                {
                    int temp = tab[j];
                    tab[j] = tab[j + 1];
                    tab[j + 1] = temp;
                }
            }
        }

        Console.WriteLine("\nTablica po sortowaniu niemalejącym:");
        Wypisz(tab);
    }

    static void Wypisz(int[] t)
    {
        foreach (int x in t)
            Console.Write(x + " ");
        Console.WriteLine();
    }
}