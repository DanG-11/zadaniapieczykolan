﻿using System;
using System.Collections.Generic;
using System.IO;

class Program
{
    static void Main()
    {
        string sciezka = "pliki/owce.txt";

        // lista zespołów (10 zespołów)
        List<int>[] zespoly = new List<int>[10];

        for (int i = 0; i < 10; i++)
        {
            zespoly[i] = new List<int>();
        }

        // wczytywanie pliku i przydział do zespołów
        int index = 0;

        foreach (string linia in File.ReadLines(sciezka))
        {
            int owca = int.Parse(linia);

            int numerZespolu = index % 10;
            zespoly[numerZespolu].Add(owca);

            index++;
        }

        // sortowanie i wyświetlanie
        for (int i = 0; i < 10; i++)
        {
            zespoly[i].Sort(); // rosnąco

            Console.WriteLine($"Zespół {i + 1}:");

            foreach (int owca in zespoly[i])
            {
                Console.Write(owca + " ");
            }

            Console.WriteLine("\n");
        }
    }
}