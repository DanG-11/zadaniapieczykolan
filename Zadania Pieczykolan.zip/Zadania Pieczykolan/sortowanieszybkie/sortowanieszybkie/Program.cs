﻿using System;
using System.IO;
using System.Linq;

class Program
{
    static void QuickSort(int[] arr, int left, int right, bool malejaco = false)
    {
        if (left < right)
        {
            int pivotIndex = Partition(arr, left, right, malejaco);
            QuickSort(arr, left, pivotIndex - 1, malejaco);
            QuickSort(arr, pivotIndex + 1, right, malejaco);
        }
    }

    static int Partition(int[] arr, int left, int right, bool malejaco)
    {
        int pivot = arr[right];
        int i = left - 1;
        for (int j = left; j < right; j++)
        {
            if ((arr[j] < pivot && !malejaco) || (arr[j] > pivot && malejaco))
            {
                i++;
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        int tempPivot = arr[i + 1];
        arr[i + 1] = arr[right];
        arr[right] = tempPivot;
        return i + 1;
    }

    static int KodMuzeum(int kod)
    {
        return kod / 1000;
    }

    static void Main()
    {
        string[] lataLines = File.ReadAllLines("lata.txt");
        int[] lata = lataLines.Select(int.Parse).ToArray();

        QuickSort(lata, 0, lata.Length - 1); 

        int rok = lata[0];
        int liczba = 1;
        int maks_rok = rok;
        int maks_liczba = 1;

        for (int i = 1; i < lata.Length; i++)
        {
            if (lata[i] == rok)
            {
                liczba++;
            }
            else
            {
                rok = lata[i];
                liczba = 1;
            }

            if (liczba > maks_liczba)
            {
                maks_liczba = liczba;
                maks_rok = rok;
            }
        }

        File.WriteAllText("ramy.txt", $"{maks_rok} {maks_liczba}");

        // --- Zadanie 1.2: Kolejność zwrotu obrazów ---
        string[] listaLines = File.ReadAllLines("lista.txt");
        int[] kody = listaLines.Select(int.Parse).ToArray();

        QuickSort(kody, 0, kody.Length - 1, true); // sortowanie malejąco

        int[] pomocnicza = kody.Select(KodMuzeum).ToArray();

        using (StreamWriter writer = new StreamWriter("kolejność.txt"))
        {
            foreach (int kod in pomocnicza)
            {
                writer.WriteLine(kod);
            }
        }

        Console.WriteLine("Program zakończył działanie. Wyniki zapisano w ramy.txt i kolejność.txt.");
    }
}