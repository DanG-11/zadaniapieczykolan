﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Podaj tekst: ");
        string tekst = Console.ReadLine().ToLower();

        int licznik = 0;
        string samogloski = "aeiouyąęó";

        foreach (char znak in tekst)
        {
            if (samogloski.Contains(znak))
            {
                licznik++;
            }
        }

        Console.WriteLine($"Liczba samogłosek: {licznik}");
    }
}
