﻿using System;

class Sorowanieprzezwstawianie
{
    static void Main(string[] args)
    {
        int[] liczby = { 5, 2, 9, 1, 5, 6 };

        Console.WriteLine("Tablica przed sortowaniem: " + string.Join(", ", liczby));

        int[] posortowane = InsertionSort(liczby);

        Console.WriteLine("Tablica po sortowaniu: " + string.Join(", ", posortowane));

        Console.WriteLine("\nNaciśnij dowolny klawisz, aby zamknąć...");
        Console.ReadKey();
    }

    public static int[] InsertionSort(int[] input)
    {
        int[] sorted = new int[input.Length];
        int size = 0;

        foreach (int value in input)
        {
            int i = size - 1;

            while (i >= 0 && sorted[i] > value)
            {
                sorted[i + 1] = sorted[i];
                i--;
            }

            sorted[i + 1] = value;
            size++;
        }

        return sorted;
    }
}