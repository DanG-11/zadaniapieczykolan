﻿using System;
using System.Collections.Generic;

class Program
{
    // Metoda sortowania kubełkowego
    static int[] BucketSort(int[] tablica)
    {
        // Szukanie największej wartości
        int max = tablica[0];

        for (int i = 1; i < tablica.Length; i++)
        {
            if (tablica[i] > max)
            {
                max = tablica[i];
            }
        }

        // Tworzenie kubełków
        List<int>[] kubelki = new List<int>[max + 1];

        for (int i = 0; i <= max; i++)
        {
            kubelki[i] = new List<int>();
        }

        // Umieszczanie elementów w kubełkach
        for (int i = 0; i < tablica.Length; i++)
        {
            kubelki[tablica[i]].Add(tablica[i]);
        }

        // Łączenie kubełków do tablicy wynikowej
        int index = 0;

        for (int i = 0; i <= max; i++)
        {
            foreach (int liczba in kubelki[i])
            {
                tablica[index] = liczba;
                index++;
            }
        }

        return tablica;
    }

    // Metoda wyświetlająca tablicę
    static void WyswietlTablice(int[] tablica)
    {
        foreach (int liczba in tablica)
        {
            Console.Write(liczba + " ");
        }

        Console.WriteLine();
    }

    static void Main(string[] args)
    {
        // Tablica testowa
        int[] tablica = { 42, 7, 19, 3, 55, 28, 11, 36 };

        Console.WriteLine("Tablica przed sortowaniem:");
        WyswietlTablice(tablica);

        // Sortowanie
        BucketSort(tablica);

        Console.WriteLine("Tablica po sortowaniu:");
        WyswietlTablice(tablica);

        Console.ReadKey();
    }
}