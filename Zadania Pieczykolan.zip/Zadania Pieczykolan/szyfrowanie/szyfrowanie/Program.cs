﻿using System;
using System.Linq;
using System.Text;

class Program
{
    static void Main()
    {
        while (true)
        {
            Console.WriteLine("\n=== MENU SZYFROWANIA ===");
            Console.WriteLine("1. Szyfr Odwrotny");
            Console.WriteLine("2. Szyfr Cezara");
            Console.WriteLine("3. Szyfr Odwrotny + Cezara (klucz = liczba liter)");
            Console.WriteLine("4. Szyfr Vigenere (klucz = 'woda')");
            Console.WriteLine("5. Szyfr Przestawieniowy (klucz = 'woda')");
            Console.WriteLine("0. Wyjście");
            Console.Write("Wybierz opcję: ");

            string choice = Console.ReadLine();
            if (choice == "0") break;

            Console.Write("Podaj tekst: ");
            string text = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    Console.WriteLine("Zaszyfrowany: " + Reverse(text));
                    Console.WriteLine("Odszyfrowany: " + Reverse(Reverse(text)));
                    break;

                case "2":
                    Console.Write("Podaj klucz (liczba): ");
                    int key = int.Parse(Console.ReadLine());
                    string enc = Caesar(text, key);
                    Console.WriteLine("Zaszyfrowany: " + enc);
                    Console.WriteLine("Odszyfrowany: " + Caesar(enc, -key));
                    break;

                case "3":
                    int autoKey = text.Count(char.IsLetter);
                    string rev = Reverse(text);
                    string enc2 = Caesar(rev, autoKey);
                    Console.WriteLine("Zaszyfrowany: " + enc2);
                    Console.WriteLine("Odszyfrowany: " + Reverse(Caesar(enc2, -autoKey)));
                    break;

                case "4":
                    string keyV = "woda";
                    string vEnc = VigenereEncrypt(text, keyV);
                    Console.WriteLine("Zaszyfrowany: " + vEnc);
                    Console.WriteLine("Odszyfrowany: " + VigenereDecrypt(vEnc, keyV));
                    break;

                case "5":
                    string keyT = "woda";
                    string tEnc = TranspositionEncrypt(text, keyT);
                    Console.WriteLine("Zaszyfrowany: " + tEnc);
                    Console.WriteLine("Odszyfrowany: " + TranspositionDecrypt(tEnc, keyT));
                    break;

                default:
                    Console.WriteLine("Nie ma takiej opcji.");
                    break;
            }
        }
    }

    // --- SZYFR ODWROTNY ---
    static string Reverse(string s) => new string(s.Reverse().ToArray());

    // --- CEZAR ---
    static string Caesar(string text, int key)
    {
        StringBuilder sb = new StringBuilder();

        foreach (char c in text)
        {
            if (char.IsLetter(c))
            {
                char offset = char.IsUpper(c) ? 'A' : 'a';
                int pos = c - offset;
                pos = (pos + key) % 26;
                if (pos < 0) pos += 26;
                sb.Append((char)(offset + pos));
            }
            else sb.Append(c);
        }
        return sb.ToString();
    }

    // --- VIGENERE ---
    static string VigenereEncrypt(string text, string key)
    {
        StringBuilder sb = new StringBuilder();
        int j = 0;

        foreach (char c in text)
        {
            if (char.IsLetter(c))
            {
                char offset = char.IsUpper(c) ? 'A' : 'a';
                int shift = char.ToLower(key[j % key.Length]) - 'a';
                int pos = (c - offset + shift) % 26;
                sb.Append((char)(offset + pos));
                j++;
            }
            else sb.Append(c);
        }
        return sb.ToString();
    }

    static string VigenereDecrypt(string text, string key)
    {
        StringBuilder sb = new StringBuilder();
        int j = 0;

        foreach (char c in text)
        {
            if (char.IsLetter(c))
            {
                char offset = char.IsUpper(c) ? 'A' : 'a';
                int shift = char.ToLower(key[j % key.Length]) - 'a';
                int pos = (c - offset - shift + 26) % 26;
                sb.Append((char)(offset + pos));
                j++;
            }
            else sb.Append(c);
        }
        return sb.ToString();
    }

    // --- PRZESTAWIENIOWY (kolumnowy) ---
    static string TranspositionEncrypt(string text, string key)
    {
        int cols = key.Length;
        int rows = (int)Math.Ceiling((double)text.Length / cols);

        char[,] table = new char[rows, cols];
        int index = 0;

        for (int r = 0; r < rows; r++)
            for (int c = 0; c < cols; c++)
                table[r, c] = index < text.Length ? text[index++] : ' ';

        var order = key
            .Select((ch, i) => new { ch, i })
            .OrderBy(x => x.ch)
            .Select(x => x.i)
            .ToArray();

        StringBuilder sb = new StringBuilder();
        foreach (int col in order)
            for (int r = 0; r < rows; r++)
                sb.Append(table[r, col]);

        return sb.ToString();
    }

    static string TranspositionDecrypt(string cipher, string key)
    {
        int cols = key.Length;
        int rows = (int)Math.Ceiling((double)cipher.Length / cols);

        char[,] table = new char[rows, cols];

        var order = key
            .Select((ch, i) => new { ch, i })
            .OrderBy(x => x.ch)
            .Select(x => x.i)
            .ToArray();

        int index = 0;
        foreach (int col in order)
            for (int r = 0; r < rows; r++)
                table[r, col] = cipher[index++];

        StringBuilder sb = new StringBuilder();
        for (int r = 0; r < rows; r++)
            for (int c = 0; c < cols; c++)
                sb.Append(table[r, c]);

        return sb.ToString().TrimEnd();
    }
}
