﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Podaj liczbę elementów tablicy: ");
        int n = int.Parse(Console.ReadLine());

        int[] tab = new int[n];
        
        Console.WriteLine("Podaj elementy tablicy:");
        for (int i = 0; i < n; i++)
        {
            Console.Write($"tab[{i}] = ");
            tab[i] = int.Parse(Console.ReadLine());
        }

        MergeSort(tab, 0, n - 1);

        Console.WriteLine("\nTablica posortowana malejąco:");
        foreach (var x in tab)
            Console.Write(x + " ");
    }

    static void MergeSort(int[] a, int l, int r)
    {
        if (l >= r) return;
        int m = (l + r) / 2;
        MergeSort(a, l, m);
        MergeSort(a, m + 1, r);
        Merge(a, l, m, r);
    }

    static void Merge(int[] a, int l, int m, int r)
    {
        int[] b = new int[r - l + 1];
        int i = l, j = m + 1, k = 0;

        while (i <= m && j <= r)
            b[k++] = a[i] > a[j] ? a[i++] : a[j++];

        while (i <= m) b[k++] = a[i++];
        while (j <= r) b[k++] = a[j++];

        for (i = 0; i < b.Length; i++)
            a[l + i] = b[i];
    }
}