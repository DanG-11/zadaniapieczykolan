﻿using System;

public static class SortowanieBombelkowe
{
    public static void BubbleSort(int[] t)
    {
        for (int i = 0; i < t.Length - 1; i++)
        {
            for (int j = 0; j < t.Length - 1; j++)
            {
                if (t[j] > t[j + 1])
                {
                    int x = t[j];
                    t[j] = t[j + 1];
                    t[j + 1] = x;
                }
            }
        }
    }
}
