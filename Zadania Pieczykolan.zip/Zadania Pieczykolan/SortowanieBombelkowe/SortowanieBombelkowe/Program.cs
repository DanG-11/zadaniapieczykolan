﻿using System;

class Program
{
    static void Main()
    {
        int[] dane = { 10, 3, 7, 1, 9, 2 };

        Console.WriteLine("Przed sortowaniem:");
        Console.WriteLine(string.Join(", ", dane));

        SortowanieBombelkowe.BubbleSort(dane);

        Console.WriteLine("Po sortowaniu:");
        Console.WriteLine(string.Join(", ", dane));
    }
}
